#include "util.h"
#include "buscar.h"

// Imprime todos os registros não removidos do arquivo.

// arquivoBin: Nome do arquivo a ser lido.
void SELECT_ALL(char *arquivoBIN) {
    // Abrindo o arquivo
    FILE *arquivo;
    arquivo = fopen(arquivoBIN,"rb+");
    // Tratamento de erro
    if(arquivo == NULL) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }
    fwrite(&c_zero,sizeof(char),1,arquivo);

    int *lista;
    estacao temp;
    nulifica_estacao(&temp);
    int tam = buscar_estacao(&temp, &lista, arquivo, true);
    
    fseek(arquivo,0,SEEK_SET);
    fwrite(&c_um,sizeof(char),1,arquivo);
    fclose(arquivo);

    return;
}